
package ProvaFinal;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;


public class Imovel {
   
    private String Proprietario;
    private String Descriçao;
    private String Categoria;
    private String Tipo;
    private String ValorVenda;

    public Imovel() {
    }

    
    public Imovel(String Proprietario, String Descriçao, String Categoria, String Tipo) {
        this.Proprietario = Proprietario;
        this.Descriçao = Descriçao;
        this.Categoria = Categoria;
        this.Tipo = Tipo;
    }

    public String getProprietario() {
        return Proprietario;
    }

    public void setProprietario(String Proprietario) {
        this.Proprietario = Proprietario;
    }

    public String getDescriçao() {
        return Descriçao;
    }

    public void setDescriçao(String Descriçao) {
        this.Descriçao = Descriçao;
    }

    public String getCategoria() {
        return Categoria;
    }

    public void setCategoria(String Categoria) {
        this.Categoria = Categoria;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }

    public String getValorVenda() {
        return ValorVenda;
    }

    public void setValorVenda(String ValorVenda) {
        this.ValorVenda = ValorVenda;
    }


    @Override
    public String toString() {
        return "proprietario:"+getProprietario()+"\n"+
               "Descrição:"+getDescriçao()+"\n"+
               "Categoria:"+getCategoria()+"\n"+
               "Tipo:"+getTipo()+"\n"+
               "Valor:"+getValorVenda()+"\n";
    }
    
    
}
