package ProvaFinal;

import com.sun.glass.events.KeyEvent;
import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class FormCadastroImovel extends javax.swing.JFrame {
    ArrayList<Imovel> imoveis=new ArrayList();
    FormMenu objMenu=new FormMenu();
    
    
    public FormCadastroImovel() {
        initComponents();
        configurarComboBox();
        configurarFormulario();
    }
    public void listar(){
        for (Imovel dados : imoveis) {
            System.out.println(dados);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnGrupo = new javax.swing.ButtonGroup();
        lblCadastro = new javax.swing.JLabel();
        lblPropietario = new javax.swing.JLabel();
        txtPropietario = new javax.swing.JTextField();
        lblDescricao = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtDescriçao = new javax.swing.JTextArea();
        lblCategoria = new javax.swing.JLabel();
        rdResidencial = new javax.swing.JRadioButton();
        rdComercial = new javax.swing.JRadioButton();
        lblTipo = new javax.swing.JLabel();
        cbxTipo = new javax.swing.JComboBox();
        lblValor = new javax.swing.JLabel();
        txtValor = new javax.swing.JTextField();
        btnCadastrar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                formKeyPressed(evt);
            }
        });

        lblCadastro.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        lblCadastro.setText("CADASDTRO DE IMÓVEIS");

        lblPropietario.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblPropietario.setText("Proprietário");

        txtPropietario.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtPropietarioFocusGained(evt);
            }
        });
        txtPropietario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPropietarioActionPerformed(evt);
            }
        });
        txtPropietario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtPropietarioKeyPressed(evt);
            }
        });

        lblDescricao.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblDescricao.setText("Desccrição");

        txtDescriçao.setColumns(20);
        txtDescriçao.setRows(5);
        txtDescriçao.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDescriçaoKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(txtDescriçao);

        lblCategoria.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblCategoria.setText("Categoria");

        btnGrupo.add(rdResidencial);
        rdResidencial.setText("Residencial");
        rdResidencial.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rdResidencialMouseClicked(evt);
            }
        });
        rdResidencial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdResidencialActionPerformed(evt);
            }
        });

        btnGrupo.add(rdComercial);
        rdComercial.setText("Comercial");
        rdComercial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdComercialActionPerformed(evt);
            }
        });

        lblTipo.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblTipo.setText("Tipo");

        cbxTipo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbxTipo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cbxTipoMouseClicked(evt);
            }
        });
        cbxTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxTipoActionPerformed(evt);
            }
        });
        cbxTipo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cbxTipoKeyPressed(evt);
            }
        });

        lblValor.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblValor.setText("Valor de Venda");

        txtValor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtValorActionPerformed(evt);
            }
        });

        btnCadastrar.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnCadastrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/iconfinder_QUARANTINE-secured-clinic-house-lock_5997210 (1).png"))); // NOI18N
        btnCadastrar.setText("CADASTRAR");
        btnCadastrar.setToolTipText("");
        btnCadastrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnCadastrarMouseClicked(evt);
            }
        });
        btnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarActionPerformed(evt);
            }
        });

        btnCancelar.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/iconfinder_button_cancel_1709.png"))); // NOI18N
        btnCancelar.setText("CANCELAR");
        btnCancelar.setToolTipText("");
        btnCancelar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnCancelarMouseClicked(evt);
            }
        });
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtPropietario, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(rdResidencial)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rdComercial)))
                        .addGap(31, 31, 31)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbxTipo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 399, Short.MAX_VALUE)))
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtValor, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblValor, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(125, 125, 125)
                        .addComponent(btnCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 156, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(173, 173, 173)
                        .addComponent(lblCadastro))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblPropietario)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(lblCadastro, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblPropietario, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtPropietario, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rdResidencial)
                    .addComponent(rdComercial)
                    .addComponent(cbxTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblValor, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtValor, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtPropietarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPropietarioActionPerformed
        
    }//GEN-LAST:event_txtPropietarioActionPerformed

    private void txtValorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtValorActionPerformed

    }//GEN-LAST:event_txtValorActionPerformed

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
        Imovel dados=new Imovel();
        dados.setProprietario(txtPropietario.getText());
        dados.setDescriçao(txtDescriçao.getText());
        if(rdComercial.isSelected()){
            dados.setCategoria(rdComercial.getText());
        }else{
            dados.setCategoria(rdResidencial.getText());
        }
        dados.setValorVenda(txtValor.getText());
        dados.setTipo((String)cbxTipo.getSelectedItem().toString());
        
        if(!dados.getProprietario().isEmpty()){
            if(!dados.getDescriçao().isEmpty()){
                if(!dados.getCategoria().isEmpty()){
                    if(!dados.getTipo().isEmpty()){
                        if(!dados.getValorVenda().isEmpty()){
                                cadastrarImoveis(dados);
                        }else{
                            JOptionPane.showMessageDialog(null,
                            "O campo valor deve ser preenchido",
                            "Valor",JOptionPane.WARNING_MESSAGE);
                        }
                    }else{
                        JOptionPane.showMessageDialog(null,
                        "O campo tipo deve ser selecionado",
                        "tipo",JOptionPane.WARNING_MESSAGE);
                    }
                }else{
                    JOptionPane.showMessageDialog(null,
                    "O campo categoria deve ser selecionado",
                    "categoria",JOptionPane.WARNING_MESSAGE);
                }
            }else{
                JOptionPane.showMessageDialog(null,
                "O campo descrição deve ser preenchido",
                "descrição",JOptionPane.WARNING_MESSAGE);
            }
        }else{
            JOptionPane.showMessageDialog(null,
            "O campo proprietário deve ser preenchido",
            "Propietário",JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_btnCadastrarActionPerformed
    
    private void btnCadastrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCadastrarMouseClicked
       objMenu.setLocationRelativeTo(null);
       objMenu.setVisible(true);
       objMenu.setResizable(false);
        for (Imovel imovei : imoveis) {
            objMenu.cadastrarImoveis(imovei);
        }
        this.dispose();
    }//GEN-LAST:event_btnCadastrarMouseClicked

    private void rdResidencialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdResidencialActionPerformed
     
    }//GEN-LAST:event_rdResidencialActionPerformed

    private void rdComercialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdComercialActionPerformed

    }//GEN-LAST:event_rdComercialActionPerformed

    private void cbxTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxTipoActionPerformed

    }//GEN-LAST:event_cbxTipoActionPerformed

    private void cbxTipoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cbxTipoMouseClicked
       
    }//GEN-LAST:event_cbxTipoMouseClicked

    private void btnCancelarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCancelarMouseClicked
        objMenu.setLocationRelativeTo(null);
        objMenu.setVisible(true);
        objMenu.setResizable(false);
        
        for (Imovel imovei : imoveis) {
            objMenu.cadastrarImoveis(imovei);
        }
        this.dispose();
    }//GEN-LAST:event_btnCancelarMouseClicked

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void formKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyPressed
     
    }//GEN-LAST:event_formKeyPressed

    private void txtPropietarioFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtPropietarioFocusGained
        
    }//GEN-LAST:event_txtPropietarioFocusGained

    private void txtPropietarioKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPropietarioKeyPressed
       if(evt.getKeyCode()==KeyEvent.VK_ENTER){
           txtDescriçao.requestFocus();
       }
    }//GEN-LAST:event_txtPropietarioKeyPressed

    private void txtDescriçaoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDescriçaoKeyPressed
         if(evt.getKeyCode()==KeyEvent.VK_ENTER){
           txtValor.requestFocus();
       }
    }//GEN-LAST:event_txtDescriçaoKeyPressed

    private void rdResidencialMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rdResidencialMouseClicked
       
    }//GEN-LAST:event_rdResidencialMouseClicked

    private void cbxTipoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cbxTipoKeyPressed
        
    }//GEN-LAST:event_cbxTipoKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
     
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormCadastroImovel().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.ButtonGroup btnGrupo;
    private javax.swing.JComboBox cbxTipo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblCadastro;
    private javax.swing.JLabel lblCategoria;
    private javax.swing.JLabel lblDescricao;
    private javax.swing.JLabel lblPropietario;
    private javax.swing.JLabel lblTipo;
    private javax.swing.JLabel lblValor;
    private javax.swing.JRadioButton rdComercial;
    private javax.swing.JRadioButton rdResidencial;
    private javax.swing.JTextArea txtDescriçao;
    private javax.swing.JTextField txtPropietario;
    private javax.swing.JTextField txtValor;
    // End of variables declaration//GEN-END:variables

    private void configurarFormulario(){
        txtPropietario.requestFocus();
        this.setTitle("Cadastro de Imóveis");
        this.setResizable(false);
        this.setLocationRelativeTo(null);
    }
    private void configurarComboBox(){
        String tp1="Apartamento";
        String tp2="Casa";
        String tp3="Chácara";
        String tp4="Sala";
        String tp5="Salão";
        String tp6="Sítio";
        
        this.cbxTipo.removeAllItems();
        this.cbxTipo.addItem(tp1);
        this.cbxTipo.addItem(tp2);
        this.cbxTipo.addItem(tp3);
        this.cbxTipo.addItem(tp4);
        this.cbxTipo.addItem(tp5);
        this.cbxTipo.addItem(tp6);
        
                
    }
    public void cadastrarImoveis(Imovel dados){
       Imovel tabela=new Imovel();
       tabela.setProprietario(dados.getProprietario());
       tabela.setDescriçao(dados.getDescriçao());
       tabela.setCategoria(dados.getCategoria());
       tabela.setTipo(dados.getTipo());
       tabela.setValorVenda(dados.getValorVenda());
       imoveis.add(tabela);
    }
   
}
